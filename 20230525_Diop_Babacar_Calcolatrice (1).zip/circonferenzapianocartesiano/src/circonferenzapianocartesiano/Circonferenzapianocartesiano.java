/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package circonferenzapianocartesiano;

/**
 *
 * @author ospite
 */
public class Circonferenzapianocartesiano {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        collocazionepunti punto1 = new collocazionepunti();
        collocazionepunti punto2 = new collocazionepunti();
        
    }
    
}
