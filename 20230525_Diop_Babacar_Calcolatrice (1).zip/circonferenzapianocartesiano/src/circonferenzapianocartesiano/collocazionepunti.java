/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package circonferenzapianocartesiano;

/**
 *
 * @author ospite
 */
import java.util.Scanner;
import java.awt.*;

public class collocazionepunti {
            int x=0;
	    int y=0;
            int e=0;
               
           
public void puntocirconferenza(){
         do{
	    
	      //lettura numero dall'esterno
	      Scanner in= new Scanner(System.in);
	    try{
	    System.out.println("inserire la x del punto:");
	    x=in.nextInt();
	    }
	    //gestione eccezione
	    catch(Exception ex){
	        System.out.println("ERRORE \n Per favore inserire un numerocome:(4 o 3.5):");
	        e=-1;
	    }
	    } while(e ==-1);
	           do{
	        //lettura numero dall'esterno
	    Scanner scanner = new Scanner(System.in);
	    try{
	    System.out.println("inserire la y del punto:");
	    y=scanner.nextInt();
	    }
	     //gestione eccezione
	    catch(Exception ex){
	        System.out.println("ERRORE \n Per favore inserire un numero come:(4 o 3.5):");
	        e=-1;
	    }
	    } while(e ==-1);
// ovali vuoti e pieni      
    } 
           public int valorex(){
                return x;
            }
           public int valorey(){
                return y;
            }
           /*public int getpunto1(){
               int x1=0;
               int 
               x1=this.x;
           }*/
           
public void cerchio(Graphics g){
            g.setColor(Color.blue);
            g.drawOval( x, y, 180, 100);
}
}

